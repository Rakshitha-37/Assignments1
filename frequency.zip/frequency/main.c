#include<stdio.h>
#include"define.h"

int main()
{
	int size;
	printf("Enter array size: ");
	scanf("%d", &size);
	int arr[size];
	int freq[size];
	scan_array(arr, size);
	count_freq(arr, freq, size);
	print_freq(arr, freq, size);
}
