#include<stdio.h>
#include"define.h"

void scan_array(int *arr, int size)
{
	printf("Enter array elements: ");
	for(int i=0;i<size;i++)
	{
		scanf("%d", &arr[i]);
	}
}
