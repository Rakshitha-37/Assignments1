#include"define.h"
#include<stdio.h>

void print_freq(int *arr, int *freq, int size)
{
	printf("Frequency of each element: \n");
	for(int i=0;i<size;i++)
	{
		if(freq[i] != flag)
		{
			printf("%d %d\n", arr[i], freq[i]);
		}
	}
}
