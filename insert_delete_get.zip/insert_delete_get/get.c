#include<stdio.h>
#include"get.h"
int get(int arr[],int n)
{
    int pos,i;
    printf("Enter the position to get the data: ");
    scanf("%d",&pos);
    for(i=0;i<n;i++)
    {
	if(i == pos)
	{
	    printf("The element is %d\n",arr[i]);
	}
    }

    return 0;
}
