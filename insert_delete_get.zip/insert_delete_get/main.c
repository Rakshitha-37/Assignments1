#include<stdio.h>
#include"insert.h"
#include"delete.h"
#include"get.h"
int main()
{
	int arr[50],n,i,option;
	printf("1.Insert\n2.Delete\n3.Getdata\n");
	printf("Enter the option: ");
	scanf("%d",&option);
	switch(option)
	{
		case 1:
			printf("Enter the size of array: ");
			scanf("%d",&n);
			printf("Enter the elements of the array: ");
			for(i=0;i<n;i++)
			{
				scanf("%d",&arr[i]);
			}
			insert(arr,n);
			break;
		case 2:
			printf("Enter the size of array: ");
			scanf("%d",&n);
			printf("Enter the elements of the array: ");
			for(i=0;i<n;i++)
			{
				scanf("%d",&arr[i]);
			}
			delete(arr,n);
			break;
		case 3:
			printf("Enter the size of array: ");
			scanf("%d",&n);
			printf("Enter the elements of the array: ");
			for(i=0;i<n;i++)
			{
				scanf("%d",&arr[i]);
			}
			get(arr,n);
			break;
	}
	return 0;
}
