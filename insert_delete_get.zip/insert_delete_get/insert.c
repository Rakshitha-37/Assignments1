#include<stdio.h>
#include"insert.h"
int insert(int arr[],int n)
{
    int num,pos,i;
    printf("Enter the data you want to insert: ");
    scanf("%d",&num);
    printf("Enter position: ");
    scanf("%d",&pos);

    if(pos <=0 || pos >n+1)
    {
	printf("Invalid position\n");
    }
    else
    {
	for(i=n;i>=pos;i--)
	{
	    arr[i+1]=arr[i];
	}
	arr[pos]=num;
	n++;
	printf("After Inserting: ");
	for(i=0;i<n;i++)
	{
	    printf("%d ",arr[i]);
	}
	printf("\n");
    }
    return 0;
}
