
int delete(int a[],int n);
