#include<stdio.h>
#include"array.h"

void print_array(int *arr1, int size)
{
	printf("Copied array elements are: ");
	for(int i=0;i<size;i++)
	{
		printf("%d ", arr1[i]);
	}
	printf("\n");
}

