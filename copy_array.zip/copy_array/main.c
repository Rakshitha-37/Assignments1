#include<stdio.h>
#include"array.h"
int main()
{
	int size;
	printf("Enter array size: ");
	scanf("%d", &size);
	int arr[size];
	int arr1[size];
	scan_array(arr, size);
	copy_array(arr, arr1, size);
	print_array(arr1, size);
}
