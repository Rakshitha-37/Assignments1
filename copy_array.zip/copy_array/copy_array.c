#include<stdio.h>
#include"array.h"

void copy_array(int *arr, int *arr1, int size)
{
	for(int i=0;i<size;i++)
	{
		arr1[i] = arr[i];
	}
}
