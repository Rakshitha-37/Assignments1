void scan_array(int *arr, int size);
void copy_array(int *arr, int *arr1, int size);
void print_array(int *arr1, int size);
