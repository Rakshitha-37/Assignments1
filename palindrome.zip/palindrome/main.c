#include<stdio.h>
#include"define.h"
int main()
{
	char str[20];
	printf("Enter a string: ");
	scanf("%s", str);
	char str1[20];
	for(int i=0;str[i] != '\0';i++)
	{
		str1[i]=str[i];
	}
	str_rev(str);
	printf("Reversed string is: %s\n", str);
	int res = str_cmp(str1, str);
	if(res == 0)
	{
		printf("String is palindrome\n");
	}
	else
	{
		printf("String is not palindrome\n");
	}
}
