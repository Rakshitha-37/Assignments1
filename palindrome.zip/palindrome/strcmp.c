#include<stdio.h>
#include"define.h"
int str_cmp(char *str1, char *str)
{
	int count=0;
	for(int i=0;str[i]!='\0';i++)
	{
		if(str[i] == str1[i])
		{
			count=0;
		}
		else if(str[i] > str1[i])
		{
			return 1; 
		}
		else
		{
			return -1;
		}
	}
	return count;
}
