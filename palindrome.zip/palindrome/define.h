void str_rev(char *str);
int str_cmp(char *str1, char *str);
