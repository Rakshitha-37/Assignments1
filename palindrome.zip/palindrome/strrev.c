#include<stdio.h>
#include<string.h>

void str_rev(char *str)
{
	int j=strlen(str);
	for(int i=0;i<j/2;i++)
	{
		char temp=str[i];
		str[i]=str[j-1];
		str[j-1]=temp;
		j--;
	}
}
