char my_strcat(char *dest, char *src);
int str_len(char *dest);
