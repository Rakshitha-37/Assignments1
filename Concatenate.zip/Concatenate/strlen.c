#include<stdio.h>
#include"define.h"

int str_len(char *dest)
{
	int len=0;
	for(int i=0;dest[i] != '\0';i++)
	{
		len++;
	}
	return len;
}
