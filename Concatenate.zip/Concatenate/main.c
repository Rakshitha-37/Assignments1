#include<stdio.h>
#include<string.h>
#include"define.h"
int main()
{
				char src[20];
				char dest[20];
				printf("Enter the source string: ");
				scanf("%s", src);
				printf("Enter the destination string: ");
				scanf("%s", dest);
				my_strcat(dest,src);
				printf("%s\n", dest);
				int len = str_len(dest);
				printf("String length is %d\n", len);
}
