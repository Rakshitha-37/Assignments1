#include<stdio.h>
#include<string.h>
#include"define.h"
char my_strcat(char *dest, char *src)
{
				int j;
				j=strlen(dest);
				for(int i=0;src[i]!='\0';i++)
				{
								dest[j]=src[i];
								j++;
				}
				dest[j]='\0';
}


