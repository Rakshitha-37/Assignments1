void first_occurence(char *str, char *word);
