#include<stdio.h>
#include"define.h"
#include<string.h>
void first_occurence(char *str, char *word)
{
	int pos, len = strlen(word), count;
	for(int i=0;str[i]!='\0';i++)
	{
		if(str[i] == word[0])
		{
			pos = i;
			count=0;
			for(int j=0;word[j] !='\0';j++)
			{
				if(str[i+j] != word[j])
				{
					break;
				}
				else
				{
					count++;
				}
			}
		}
		if(count == len)
		{
			break;
		}
	}
	printf("%s is found at %d position\n", word, pos);
}

