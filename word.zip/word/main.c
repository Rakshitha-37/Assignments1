#include<stdio.h>
#include"define.h"

int main()
{
	char str[50];
	char word[20];
	printf("Enter the string: ");
	scanf("%[^\n]%*c", str);
	printf("Enter the word to be searched: ");
	scanf("%[^\n]%*c", word);
	first_occurence(str, word);
}
